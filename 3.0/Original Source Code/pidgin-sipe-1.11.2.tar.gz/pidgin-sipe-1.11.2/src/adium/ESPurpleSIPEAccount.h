//
//  ESSIPEAccount.h
//  SIPEAdiumPlugin
//
//  Created by Matt Meissner on 10/30/09.
//  Copyright 2009 Matt Meissner. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <AdiumLibpurple/CBPurpleAccount.h>

@interface ESPurpleSIPEAccount : CBPurpleAccount <AIAccount_Files> {

}
@end
